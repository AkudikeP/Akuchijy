<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'mobile_darzi';
$config['googleplus']['client_id']        = '632908443461-eera51rs9q7on0kslc33mmfkj2prk54i.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'g8ASfsCYp5uxub7CWbcsAGSZ';
$config['googleplus']['redirect_uri']     = 'http://mobiledarzi.com/welcome/login';
//$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

