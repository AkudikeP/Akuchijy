<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


	$config['appId']   = '379206922253258';
	$config['secret']  = '54789d7dc38a8326ed0329f89ff62d01';

/*$config['appId']   = '540679022735765';
	$config['secret']  = '39e0cde3c313ac29dffadd9e42fd3e2f';*/

?>
