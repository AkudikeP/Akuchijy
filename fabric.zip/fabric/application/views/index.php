<!DOCTYPE html>
<html lang="en">
<head>
<title>OneTech</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="OneTech shop project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>styles/bootstrap4/bootstrap.min.css">
<link href="<?php echo base_url(); ?>plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>plugins/slick-1.8.0/slick.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>styles/responsive.css">

</head>

<body>

<div class="super_container">
	
	<!-- Header -->
	
	<header class="header">

		<!-- Header Main -->

		<div class="header_main">
			<div class="container">
				<div class="row">

					<!-- Logo -->
					<div class="col-lg-2 col-sm-3 col-3 order-1">
						<div class="logo_container">
							<div class="logo"><a href="#">Ansvel Fabric</a></div>
						</div>
					</div>

					<!-- Search -->
					<div class="col-lg-6 col-12 order-lg-2 order-3 text-lg-left text-right">
						<div class="header_search">
							<div class="header_search_content">
								<div class="header_search_form_container">
									<form action="#" class="header_search_form clearfix">
										<input type="search" required="required" class="header_search_input" placeholder="Search for products...">
								
										<button type="submit" class="header_search_button trans_300" value="Submit"><img src="<?php echo base_url(); ?>images/search.png" alt=""></button>
									</form>
								</div>
							</div>
						</div>
					</div>

					<!-- Wishlist -->
					<div class="col-lg-4 col-9 order-lg-3 order-2 text-lg-left text-right">
						<div class="wishlist_cart d-flex flex-row align-items-center justify-content-end">
					

							<!-- Cart -->
							<div class="cart">
								<div class="cart_container d-flex flex-row align-items-center justify-content-end">
									<div class="cart_icon">
										<img src="<?php echo base_url(); ?>images/cart.png" alt="">
										<div class="cart_count"><span>10</span></div>
									</div>
									<div class="cart_content">
										<div class="cart_text"><a href="#">Cart</a></div>
										<div class="cart_price">$85</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Main Navigation -->

		<nav class="main_nav">
			<div class="container">
				<div class="row">
					<div class="col">
						
						<div class="main_nav_content d-flex flex-row">

		
							<!-- Main Nav Menu -->


             


							<div class="main_nav_menu ml-auto">
								<ul class="standard_dropdown main_nav_dropdown">
									<li><a href="#">All Fabric</a></li>
									<li class="hassubs">
										<a href="#">Décor Fabric</a>
									
									</li>
									<li class="hassubs">
										<a href="#">Apparel Fabric</a>
							
									</li>
									<li class="hassubs">
										<a href="#">Utility Fabric</a>
									</li>
									<li><a href="blog.html">Craft Fabric</a></li>
									<li><a href="contact.html">Supplies</a></li>
									<li><a href="contact.html">Wallpaper</a></li>
									<li><a href="contact.html">New</a></li>
									<li><a href="contact.html">Clearance</a></li>
									<li><a href="contact.html">Maker's Mill</a></li>
								</ul>
							</div>

							<!-- Menu Trigger -->

							<div class="menu_trigger_container ml-auto">
								<div class="menu_trigger d-flex flex-row align-items-center justify-content-end">
									<div class="menu_burger">
										<div class="menu_trigger_text">menu</div>
										<div class="cat_burger menu_burger_inner"><span></span><span></span><span></span></div>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
		</nav>
		
		<!-- Menu -->

		<div class="page_menu">
			<div class="container">
				<div class="row">
					<div class="col">
						
						<div class="page_menu_content">
							
							<div class="page_menu_search">
								<form action="#">
									<input type="search" required="required" class="page_menu_search_input" placeholder="Search for products...">
								</form>
							</div>
							<ul class="page_menu_nav">
								<li class="page_menu_item has-children">
									<a href="#">Language<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="#">English<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Italian<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Spanish<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Japanese<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item has-children">
									<a href="#">Currency<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="#">US Dollar<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">EUR Euro<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">GBP British Pound<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">JPY Japanese Yen<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item">
									<a href="#">Home<i class="fa fa-angle-down"></i></a>
								</li>
								<li class="page_menu_item has-children">
									<a href="#">Super Deals<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="#">Super Deals<i class="fa fa-angle-down"></i></a></li>
										<li class="page_menu_item has-children">
											<a href="#">Menu Item<i class="fa fa-angle-down"></i></a>
											<ul class="page_menu_selection">
												<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
												<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
												<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
												<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
											</ul>
										</li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item has-children">
									<a href="#">Featured Brands<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="#">Featured Brands<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item has-children">
									<a href="#">Trending Styles<i class="fa fa-angle-down"></i></a>
									<ul class="page_menu_selection">
										<li><a href="#">Trending Styles<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
										<li><a href="#">Menu Item<i class="fa fa-angle-down"></i></a></li>
									</ul>
								</li>
								<li class="page_menu_item"><a href="blog.html">blog<i class="fa fa-angle-down"></i></a></li>
								<li class="page_menu_item"><a href="contact.html">contact<i class="fa fa-angle-down"></i></a></li>
							</ul>
							
							<div class="menu_contact">
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="<?php echo base_url(); ?>images/phone_white.png" alt=""></div>+38 068 005 3570</div>
								<div class="menu_contact_item"><div class="menu_contact_icon"><img src="<?php echo base_url(); ?>images/mail_white.png" alt=""></div><a href="mailto:fastsales@gmail.com">fastsales@gmail.com</a></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</header>
	
	<!-- Banner -->



		<div class="">
			<div class="row ">

								<div class="col-lg-3">
				<div class="row" style="margin-left: 60px; margin-bottom: 30px; font-size: 18px">

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-color.png" style="width: 60%">
						<br>
						Shop by color
					</div>

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-brand.png" style="width: 60%">
						<br>
						Shop by Brand
					</div>
					
				</div>

						<div class="row" style="margin-left: 60px; margin-bottom: 30px; font-size: 18px">

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-design.png" style="width: 60%">
						<br>
						Shop by Design
					</div>

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-use.png" style="width: 60%">
						<br>
						Shop by Use
					</div>
					
				</div>

								<div class="row" style="margin-left: 60px; margin-bottom: 30px; font-size: 18px">

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-fabric-type.png" style="width: 60%">
						<br>
						Shop by Product Type
					</div>

					<div class="col-sm-5">

						<img src="<?php echo base_url(); ?>images/shop-by-characteristic.png" style="width: 60%">
						<br>
					Shop by Characterisics
					</div>
					
				</div>

					

						
					
				</div>
				<div class="col-lg-7"><img src="<?php echo base_url(); ?>images/home.jpg" alt="" style="width: 100%"></div>
				<div class="col-lg-2">
					

					<div class="col-sm-12" style="padding: 10px; margin-bottom: 10px; text-align: center; border: 1px solid #ccc; font-size: 14px">

						Quilting Fabric<br>

Cotton prints, broadcloth, flannel & more
						
					</div>

							<div class="col-sm-12" style="padding: 10px; margin-bottom: 10px; text-align: center; border: 1px solid #ccc; font-size: 14px">

		Licensed Fabric
<br>
Your favorite characters & teams
						
					</div>

							<div class="col-sm-12" style="padding: 10px; margin-bottom: 10px; text-align: center; border: 1px solid #ccc; font-size: 14px">

	Decorative Pillows<br>

Ready-made throw pillows for your home
						
					</div>

							<div class="col-sm-12" style="padding: 10px; margin-bottom: 10px; text-align: center; border: 1px solid #ccc; font-size: 14px">

Clearance<br>

Up to 40% off closeout fabric & supplies
						
					</div>



						
					
				</div>
			</div>
		</div>
	
	<!-- Characteristics -->

	<div class="characteristics">
		<div style="margin-left: 5px; margin-right: 5px">
			<div class="row">

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
					<div class="char_item d-flex flex-row align-items-center justify-content-start">
				
						<div class="char_content">
							<div class="char_title">High Quality Products</div>
							<div class="char_subtitle">We sell only first quality fabric so you can be sure your projects will be perfect every time. </div>
						</div>
					</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-3 col-md-6 char_col">
					
					<div class="char_item d-flex flex-row align-items-center justify-content-start">
				
						<div class="char_content">
							<div class="char_title">Everyday Low Prices</div>
							<div class="char_subtitle">We’ve spent decades building relationships with suppliers, so you can be confident that whenever you buy, you will be getting a fantastic price!</div>
						</div>
					</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-3 col-md-6 char_col">
					
					<div class="char_item d-flex flex-row align-items-center justify-content-start">
					
						<div class="char_content">
							<div class="char_title">Great Customer Service</div>
							<div class="char_subtitle">Have a question? Looking for that hard-to-find fabric? Just Ask!
Our knowledgeable customer service is here to help. </div>
						</div>
					</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
					<div class="char_item d-flex flex-row align-items-center justify-content-start">
						
						<div class="char_content">
							<div class="char_title">Excellent Selection</div>
							<div class="char_subtitle">With over 50,000 products, you can find just what you need. (And don’t forget about the supplies!) </div>
						</div>
					</div>
				</div>

							<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
					<div class="char_item d-flex flex-row align-items-center justify-content-start">
						
						<div class="char_content">
							<div class="char_title">Information & Inspiration</div>
							<div class="char_subtitle">Be sure to visit OFS Maker’s Mill where you’ll find tutorials, product guides, and ideas. </div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<div class="row" style=" margin-left: 40px;">
	
	<a href=""><div style="height: 70px; width: 70px; background: #c0392b ; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background:  #7fb3d5; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background:  #f1c40f; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #27ae60; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background:  #34495e; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #1c2833; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #6e2c00 ; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #f2f3f4 ; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #f1948a ; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #3498db; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #4a235a; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #e9f7ef; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #566573; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #b7950b; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #0b5345 ; margin-right: 10px;"></div></a>

	<a href=""><div style="height: 70px; width: 70px; background: #d5d8dc; margin-right: 10px;"></div></a>




</div>


	<div class="trends">
	
<div>
	
		<div class="container">
			<div class="row">

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">

									<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/BURNAT_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Burlap</h4>

Burlap is a 100% jute material that’s perfect for lawn and garden projects, crafts, home decorating, and wedding décor. Choose from our selection of natural burlap, dyed color burlap, or other specialty jute fabrics</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
				<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/1060_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Canvas</h4>

Canvas fabric, also known as cotton duck, is a durable utility fabric that can also be used for décor, crafts, and apparel like jackets. We carry both natural canvas and many colors of dyed canvas in a variety of weights.

</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/CHEE10_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Cheesecloth</h4>

Cheesecloth is a loosely woven fabric available in various grades that’s commonly used for straining sauces and making cheese. It’s also great for wiping and polishing, draping at weddings, theater backdrops, and Halloween decorations and costumes. 
</div>
				</div>

				<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/8014_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Muslin</h4>

Popular in dressmaking and theatrical design, muslin can also be used for crafts, home décor projects, and more. We carry a wide selection of bleached muslin and unbleached muslin in a variety of widths and weights. 

</div>
				</div>


								<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/23505_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Drapery Lining</h4>
Drapery lining not only makes window treatments look better visually, it also adds a functional component to them. Use blackout lining or insulating drapery lining to block light, sound, and cold drafts. 
</div>
				</div>

												<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/D1000100C_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Clear Vinyl</h4>

From ultra-thin 4 gauge clear vinyl to heavy duty 60 gauge clear vinyl, we carry the perfect vinyl for your automotive, marine, and home project needs. This non-yellowing and waterproof clear vinyl can withstand the elements in extreme hot and cold environments. 

</div>
				</div>



						<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/PDF-XX14-SQR_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Pillow Forms</h4>

Shop our selection of pillow forms in many sizes and shapes including round and bolster pillows. Choose from down pillow inserts, polyester pillows, or inserts filled with a down and polyester blend. 
</div>
				</div>


						<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/481236-2635_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Foam</h4>

Available in a range of sizes, upholstery foam is essential for many indoor, outdoor, and marine applications. We also offer other varieties of foam including acoustic foam, packing foam, mattress foam, and sew foam. 

</div>
				</div>


						<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/BURBAG26_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Burlap Bags</h4>

Burlap bags are great for storage, landscaping, crafts, home décor, and sack races! We offer hydrocarbon free burlap bags, printed burlap bags, and authentic used burlap coffee bags. 
</div>
				</div>

						<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/T110-41_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Party & Event Décor</h4>

If you’re planning a wedding or a party, take a look at our event decorations including table runners, tablecloths, and aisle runners. We also offer favor bags and ribbon in a variety of materials. 

</div>
				</div>

						<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/120080_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Upholstery Fabric</h4>

We offer a wide selection of durable upholstery fabrics for couches, slipcovers, dining chairs, ottomans, headboards, and more. Shop upholstery materials like velvet, vinyl, denim, ticking, and designer upholstery fabric. 

</div>
				</div>


										<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/FF5621-0000_3.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Outdoor Fabric</h4>

Durable, water-resistant outdoor fabric can be used both indoors and out for upholstery, throw pillows, curtains, and bags. Sunbrella fabric is popular for patio furniture, marine upholstery, boat covers, awnings, and more. 

</div>
				</div>


														<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/SVI-005_2.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Vinyl & Faux Leather</h4>

Vinyl fabric can be used for both decorative and utility purposes. Upholstery vinyl and PVC-free faux leather are great for upholstered furniture, auto and marine upholstery, and even handbags. Our selection of utility vinyl includes clear vinyl, flannel backed vinyl, and tarp vinyl. 

</div>
				</div>

														<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/GRAOAT_2.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Linen</h4>
Known for being both durable and breathable, linen fabric provides a casual yet elegant look for curtains and apparel. Our linen is available in many colors and weights including lightweight Irish linen, and heavyweight Belgian linen.  

</div>
				</div>


														<!-- Char. Item -->
				<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/PCB932_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Broadcloth</h4>

Broadcloth is an all-purpose, lightweight fabric commonly used for quilts, clothing, accessories, bias tape, linings, and much more. With dozens of colors to choose from, broadcloth is available in either 100% cotton or a poly/cotton blend.

</div>
				</div>


							<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/SCRNAT_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Scrim</h4>

Commonly used as a theater backdrop, scrim has many other uses including airy curtains, photography light diffusers, and wedding draping. Our affordable cotton scrim is a semi-sheer, gauzy material offered in both white and natural. 

</div>
				</div>

							<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/CBS927_1.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Satin</h4>

Satin is a popular fashion and apparel fabric that is available in many styles. Lustrous bridal satin is perfect for formalwear, apparel lining, and costumes. Satin can also be used for event décor like backdrops and tablecloths. 

</div>
				</div>


							<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/SFLECHA_2.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Fleece</h4>

Fleece is a soft and warm material that is popular for making blankets, scarves, mittens, hats, and jackets. It’s available in a variety of colors and prints including NFL fleece and other licensed prints. 
</div>
				</div>


							<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/PVEL738_2.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Velvet</h4>

Velvet is a soft plush fabric that is available in a variety of styles. Lightweight apparel velvet tends to have more stretch which is great for clothing and costumes. Durable upholstery velvet has a stiff backing and is suitable for high traffic furniture. 

</div>
				</div>

							<div class="col-lg-2 col-md-6 char_col">
					
								<div class="trends_image d-flex flex-column align-items-center justify-content-center"><img src="images/fabric/TUL108-1130_2.jpg" alt=""></div>
								
					<div class="trends_image d-flex flex-column align-items-center"> 
						<h4>Tulle</h4>

Tulle is a fine netting used for apparel, hats, tutus, and event decorations. It’s often used to create volume under skirts and dresses. We offer tulle by the bolt, glitter tulle by the yard, and spools of decorative tulle. 

</div>
				</div>



			</div>
		</div>

</div>
	</div>





	<!-- Newsletter -->

	<div class="newsletter">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="newsletter_container d-flex flex-lg-row flex-column align-items-lg-center align-items-center justify-content-lg-start justify-content-center">
						<div class="newsletter_title_container">
							<div class="newsletter_icon"><img src="images/send.png" alt=""></div>
							<div class="newsletter_title">Sign up for Newsletter</div>
							<div class="newsletter_text"><p>...and receive %20 coupon for first shopping.</p></div>
						</div>
						<div class="newsletter_content clearfix">
							<form action="#" class="newsletter_form">
								<input type="email" class="newsletter_input" required="required" placeholder="Enter your email address">
								<button class="newsletter_button">Subscribe</button>
							</form>
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row">

				<div class="col-lg-3 footer_col">
					<div class="footer_column footer_contact">
						<div class="logo_container">
							<div class="logo"><a href="#">Ansvel Fabric</a></div>
						</div>
						<div class="footer_title">Got Question? Call Us 24/7</div>
						<div class="footer_phone">+234070</div>
						<div class="footer_contact_text">
							<p>Ajah</p>
							<p>Lagos</p>
						</div>
						<div class="footer_social">
							<ul>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-youtube"></i></a></li>
								<li><a href="#"><i class="fab fa-google"></i></a></li>
								<li><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
							</ul>
						</div>
					</div>
				</div>


    
    
    
  
    
    
    


				<div class="col-lg-2 offset-lg-2">
					<div class="footer_column">
						<div class="footer_title">Find it Fast</div>
						<ul class="footer_list">
							<li><a href="#">Fabric Remnants</a></li>
							<li><a href="#">Gift Certificates</a></li>
							<li><a href="#">Drapery Yardage Calculator</a></li>
							<li><a href="#">Upholstery Yardage Chart</a></li>
							<li><a href="#">Fabric Glossary</a></li>
							<li><a href="#">Fabric Quote</a></li>
							<li><a href="#">Affiliates</a></li>
						</ul>
					
					</div>
				</div>


    
    
    
    
    
    
    
    

				<div class="col-lg-2">
					<div class="footer_column">
						<div class="footer_title">Customer Care</div>
						<ul class="footer_list">
							<li><a href="#">Contact Us</a></li>
							<li><a href="#">About Us</a></li>
							<li><a href="#">Careers</a></li>
							<li><a href="#">Customer Services</a></li>
							<li><a href="#">FAQ</a></li>
							<li><a href="#">Shipping & Returns</a></li>
							<li><a href="#">Terms</a></li>
							<li><a href="#">Privacy</a></li>
							<li><a href="#">Sitemap</a></li>
						</ul>
					</div>
				</div>

			</div>
		</div>
	</footer>

	<!-- Copyright -->

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col">
					
					<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
						<div class="copyright_content">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 

</div>
						<div class="logos ml-sm-auto">
							<ul class="logos_list">
								<li><a href="#"><img src="images/logos_1.png" alt=""></a></li>
								<li><a href="#"><img src="images/logos_2.png" alt=""></a></li>
								<li><a href="#"><img src="images/logos_3.png" alt=""></a></li>
								<li><a href="#"><img src="images/logos_4.png" alt=""></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/slick-1.8.0/slick.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="js/custom.js"></script>
</body>

</html>